SP Football Life 2023 Aspect Ratio Fix
--------------------------------------
By default SPFL2023 only supports 16:9 aspect ratio, so if playing on Steam Deck or 
in ultrawide, you will get black bars at the top and bottom or sides.

This mod should fix the aspect ratio so that matches play in proper fullscreen. It is 
installed automatically if using my Lutris install script for Linux/Steam Deck:
https://github.com/eskay993/gamefiles/tree/main/sp-football-life-2023


Manual install:
-------------
- Navigate to where you installed SP Football Life 2023

- Copy aspectratio.lua to the SiderAddons\modules folder

- Edit SiderAddons\sider.ini and add the following line to the end of the list of lua.modules:

    lua.module = "aspectratio.lua"

It should look something like this:

	lua.enabled = 1
	luajit.ext.enabled = 1
	lua.module = "lib\CommonLib.lua"
	lua.module = "common\stadiums.lua"
	lua.module = "common\scoreboards.lua"
	lua.module = "common\cinematics.lua"
	lua.module = "common\referee.lua"
	lua.module = "common\audio.lua"
	lua.module = "common\omb.lua"
	lua.module = "common\kits.lua"
	lua.module = "env.lua"
	lua.module = "camera.lua"
	lua.module = "matchset.lua"
	lua.module = "nets.lua"
	lua.module = "aspectratio.lua"

- Start the game and the mod should load automatically. You will still see black bars
in menus, but the actuall match / gameplay should now be fulscreen with no bars.
