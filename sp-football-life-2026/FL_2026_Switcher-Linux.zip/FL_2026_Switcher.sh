#!/usr/bin/env bash

title="FL26 Switcher"

yad="tools/yad"

cpks_dir="switcher"
log_dir="dataSP"

# Matghes both the dir names and the log txt file names
gp_lbl="GP"
controller_lbl="Controller"
classics_lbl="Classics"

gp_cpk="Data/dt18_all.cpk"
controller_cpk="download/SMK_Addcontrol.cpk"
classics_cpk="download/08_smkdb_ulk.cpk"

set_opts() {
    local name="$1"
    local opts=""
    local current="$(<$log_dir/$name.txt)"

    [ "$current" = "0" ] && echo FALSE && return
    [ "$current" = "1" ] && echo TRUE && return

    for cpk in "$cpks_dir/$name"/*; do
        cpk="$(basename "$cpk")"
        [ "$cpk" = "$current" ] && opts+="^"
         opts+="$cpk!"
    done
    opts=${opts%\!*} # Removes last !
    echo $opts
}

switch_cpk() {
    local name="$1"
    local choice="$2"
    local dst="$3"

    [ "$choice" = "FALSE" ] && choice="0"
    [ "$choice" = "TRUE" ] && choice="1"

    cpk="$(basename $dst)"
    src="$cpks_dir/$name/$choice/$cpk"

    cp -v "$src" "$dst"

    echo "$choice" > "$log_dir/$name.txt"
}

choices=$( $yad --form --title="$title" \
    --width=350  \
    --form --field="Gameplay Vesion:CB" "$(set_opts "$gp_lbl")" \
    --form --field="Controller Buttons:CB" "$(set_opts "$controller_lbl")" \
    --form --field="Enable Legends in career modes:CHK" $(set_opts "$classics_lbl") \
) || exit

gp_choice=$(cut -d '|' -f1 <<< "$choices")
controller_choice=$(cut -d '|' -f2 <<< "$choices")
classics_choice=$(cut -d '|' -f3 <<< "$choices")

switch_cpk "$gp_lbl" "$gp_choice" "$gp_cpk"
switch_cpk "$controller_lbl" "$controller_choice" "$controller_cpk"
switch_cpk "$classics_lbl" "$classics_choice" "$classics_cpk"
