FL26 Switcher for Linux
-----------------------

Recreating the FL Switcher in bash for easy use in Linux

Instructions:
Unzip this to game install folder and run it from there.

If using KDE / Dolphin, just double click it and choose "Launch".