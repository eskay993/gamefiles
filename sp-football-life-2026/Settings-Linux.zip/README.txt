FL Settings for Linux
---------------------

Partial recreation of the FL's Settings.exe for linux using bash.

Only option that are included for now are:

- Display - Windows or Full screen
- Vsync - Enable1 or Enable 2
- Controller -Xinput or DirectInput

In future I may add resolution setting as well.

Instructions:
Just unzip to where you game save is location. This could be in one of 2 places:

~/Documents/KONAMI/eFootball PES 2021 SEASON UPDATE

or

<path-to-game-prefix>/drive_c/users/<your_username>/Documents/KONAMI/eFootball PES 2021 SEASON UPDATE

You know you are in the right place if you see a settings.dat file.

If you are use KDE / Dolphin, just double click it to run and choose "Launch"


