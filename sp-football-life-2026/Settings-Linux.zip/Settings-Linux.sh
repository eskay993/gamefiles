#!/usr/bin/env bash

# Tool to modify SPFL settings natively in Linux.
#
# Settings are read from setting.dat.
# 2 bytes (4 numbers) are read starting at offset 8
# First nummber = controller settings (6=dinput, 7=xinput)
# Second number = screen mode (6=windowed, 7=fullscreen)
# Third number = always 0
# Fourth number = vsync mode (2=disabled, 4=enable1, 8=enable2)
# So for example, 0x7604 would be xinput (7), windowed (6), enable1 (4)

datfile="settings.dat"
offset="8"

declare -A screen_map
screen_map[6]="Windowed"
screen_map[7]="Full Screen"

declare -A controller_map
controller_map[6]="DirectInput"
controller_map[7]="XInput"

declare -A vsync_map
vsync_map[02]="Disabled"
vsync_map[04]="Enable1"
vsync_map[08]="Enable2"

get_key() {
   local val="$1"
   local map_name="$2"
   local key

   declare -n map="$map_name"
   for key in "${!map[@]}"; do
       if [[ "${map[$key]}" == "$val" ]]; then
           printf "%s" "$key"
           return 0
       fi
   done

   return 1
}

get_opts() {
   local current_val="$1"
   local map_name="$2"
   local sorted_vals
   local key

   declare -n map="$map_name"
   for key in $(printf "%s\n" "${!map[@]}" | sort -n); do
       sorted_vals+=("${map[$key]}")
   done
   
   IFS='!'
   opts=$(printf '%s\n' "${sorted_vals[@]}")
   # Add a ^ before the current value so it's pre-selected in the dropdown
   opts=$(sed "s/^${map[$current_val]}$/^&/" <<< "$opts")
   echo $opts | paste -sd'!'
}

# Read bytes 8 and 9
opt_bytes_in=$(xxd -p -s $offset -l 2 "$datfile")

controller_val="${opt_bytes_in:0:1}"
screen_val="${opt_bytes_in:1:1}"
vsync_val="${opt_bytes_in:2:2}"

choices=$( yad --form --title="SPFL Settings" \
    --width=300 \
    --field="Screen Mode:CB" "$(get_opts "$screen_val" screen_map)" \
    --field="Vsync:CB" "$(get_opts "$vsync_val" vsync_map)" \
    --field="Controller:CB" "$(get_opts "$controller_val" controller_map)"
) || exit

screen_choice=$(cut -d '|' -f1 <<< "$choices")
vsync_choice=$(cut -d '|' -f2 <<< "$choices")
controller_choice=$(cut -d '|' -f3 <<< "$choices")

# Exit on any error to avoid corrupted the dat file
opt_bytes_out=$(get_key "$controller_choice" controller_map) || { echo "Unknown value '$controller_choice'. Aborting."; exit 1; }
opt_bytes_out+=$(get_key "$screen_choice" screen_map) || { echo "Unknown value '$screen_choice' Aborting."; exit 1; }
opt_bytes_out+=$(get_key "$vsync_choice" vsync_map) || { echo "Unknown value '$vsync_choice'. Aborting."; exit 1; }

if [[ $opt_bytes_out != $opt_bytes_in ]]; then
    if [ ! -f "${datfile}.backup" ]; then
        cp "${datfile}" "${datfile}.backup"
    fi
    printf "\x${opt_bytes_out:0:2}\x${opt_bytes_out:2:2}" | dd of=settings.dat bs=1 seek=$offset conv=notrunc
fi
