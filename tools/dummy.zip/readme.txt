Dummy exe needed for some scripts to work. Can be used to replace any exe that you want
to prevent from running during an install process.

For reference, this is just a empty bat file converted to exe and does nothing when launched.
