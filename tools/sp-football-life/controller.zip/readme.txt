SP Football Life Controller Buttons
--------------------------------------
SmokePatch has a tool to change the controller buttons here:

https://www.pessmokepatch.com/2017/03/smoke-buttons.html

But some are having trouble running it on Linux/Steam Deck. You 
can install them manually using the files in this zip.

Manual install:
-------------
- Navigate to the 'download' inside where you installed SP Football Life

- Backup 'SMK_Addcontrol.cpk'

- Copy the 'SMK_Addcontrol.cpk' from the zip that you want into the 'download' folder